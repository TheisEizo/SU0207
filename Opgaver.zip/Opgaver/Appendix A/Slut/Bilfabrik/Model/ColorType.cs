﻿namespace Bilfabrik.Model
{
    enum ColorType
    {
        Red, Green, Black, Yellow
    }
}
