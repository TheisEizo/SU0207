﻿using Bilfabrik.Model.Steering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bilfabrik.Model
{
    abstract class Car : IComparable
    {
        /// <summary>
        /// Override of the Method, to allow creation based on the Car-viewmodel
        /// </summary>
        /// <param name="car"></param>
        /// <returns></returns>
        public static Car CreateCar(ViewModel.Car car)
        {
            return CreateCar(car.Type, car.Brand, car.NumberOfSeats, car.NumberOfWheels, car.Color, car.Steering);
        }
        public static Car CreateCar(CarType type, string brand, int numberOfSeats, int numberOfWheels, ColorType color, SteeringType steeringType)
        {
            Car carToReturn = null;

            ISteering steering = null;
            // Hvilken styring skal bruges 
            // - fra start er der kun rattet!
            switch (steeringType)
            {
                case SteeringType.SteeringWheel:
                    steering = new SteeringWheel();
                    break;
                case SteeringType.Joystick:
                    steering = new Joystick();
                    break;
                case SteeringType.Brain:
                    steering = new Brain();
                    break;
                default:
                    steering = new SteeringWheel();
                    break;
            }

            // Hvilken biltype - opret klasse, svarende til brugerens valg
            switch (type)
            {
                case CarType.Personal:
                    carToReturn = new Personal(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.SUV:
                    carToReturn = new SUV(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.Van:
                    carToReturn = new Van(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.Truck:
                    carToReturn = new Truck(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.Bus:
                    carToReturn = new Bus(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                default:
                    throw new NotImplementedException(string.Format( "Enum: {0} not implemented", type));
            }

            return carToReturn;
        }
        public static Car CreateCar(string persistedCar)
        {
            Car result = null;

            var parts = persistedCar.Split(';');
            try
            {
                var type = (CarType)Enum.Parse(typeof(CarType), parts[0]);
                var brand = parts[1];
                var color = (ColorType)Enum.Parse(typeof(ColorType), parts[2]);
                var numberOfWheels = int.Parse(parts[3]);
                var numberOfSeats = int.Parse(parts[4]);
                var steering = (SteeringType)Enum.Parse(typeof(SteeringType), parts[5]);

                result = CreateCar(type, brand, numberOfSeats, numberOfWheels, color, steering);
            }
            catch
            {
                // Ingen kode - vil bare returnere en null-værdi
            }
            return result;
        }

        public Car(string brand, int numberOfSeats, int numberOfWheels, ColorType color, CarType type, ISteering steering)
        {
            Brand = brand;
            NumberOfSeats = numberOfSeats;
            NumberOfWheels = numberOfWheels;
            Color = color;
            Type = type;

            Steering = steering;
        }

        public string GetPersistingString()
        {
            var result = $"{Type};{Brand};{Color};{NumberOfWheels};{NumberOfSeats};{Steering.GetType().Name}";
            return result;
        }


        public string Brand { get; set; }
        public int NumberOfSeats { get; set; }
        public int NumberOfWheels { get; set; }
        public ColorType Color { get; set; }
        public CarType Type { get; set; }

        public ISteering Steering { get; set; }

        // Metoder til at håndtere antal sæder og hjul
        // - skal implementeres i de nedarvende klasser!
        public abstract bool WheelsIsAllowed();
        public abstract string TextAboutWheels { get; }
        public abstract bool SeatsIsAllowed();
        public abstract string TextAboutSeats { get; }


        public override string ToString()
        {
            var text = string.Format("{0} {1} {2}, styret af {3}, med {4} sæder og {5} hjul.", Color, Brand, Type, Steering, NumberOfSeats, NumberOfWheels);
            return text;
        }

        public int CompareTo(object obj)
        {
            // obj er en anden instans af Car, så vi kan Cast'e.
            // Vi sammenligner på Brand - så kan vi bruge CompareTo-metoden direkte på variablen
            return Brand.CompareTo(((Car)obj).Brand);

        }
    }
}
