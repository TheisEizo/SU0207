﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bilfabrik.Model.Steering;

namespace Bilfabrik.Model
{
    class SUV : Car
    {
        public SUV(string brand, int numberOfSeats, int numberOfWheels, ColorType color, ISteering steering) 
            : base(brand, numberOfSeats, numberOfWheels, color, CarType.SUV, steering)
        {
        }

        public override string TextAboutSeats
        {
            get
            {
                return "Skal have 2-6 sæder";
            }
        }

        public override string TextAboutWheels
        {
            get
            {
                return "Skal have 4 hjul";
            }
        }

        public override bool SeatsIsAllowed()
        {
            return NumberOfSeats >= 2 && NumberOfSeats <= 6;
        }

        public override bool WheelsIsAllowed()
        {
            return NumberOfWheels == 4;
        }
    }
}
