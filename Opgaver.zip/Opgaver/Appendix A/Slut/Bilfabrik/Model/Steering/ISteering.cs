﻿namespace Bilfabrik.Model.Steering
{
    interface ISteering
    {
        string SoundTheHorn();
        string TurnLeft(int degrees);
        string TurnRight(int degrees);
    }
}