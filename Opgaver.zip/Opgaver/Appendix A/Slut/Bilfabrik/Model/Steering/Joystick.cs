﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bilfabrik.Model.Steering
{
    class Joystick : ISteering
    {
        public string MoveRight(int degrees)
        {
            return string.Format("The joystick is held right by {0} degrees" ,degrees);
        }

        public string MoveLeft(int degrees)
        {
            return string.Format("The joystick is held left by {0} degrees",  degrees);
        }

        public string MoveForward(int degrees)
        {
            return string.Format("The joystick is held forward by {0} degrees", degrees);
        }

        public string MoveBack(int degrees)
        {
            return string.Format("The joystick is held back by {0} degrees", degrees);
        }

        public string PressButton(int buttonNumberToPress)
        {
            return string.Format("Button {0} is pressed on the joystick", buttonNumberToPress);

        }

        public override string ToString()
        {
            return "JoyStick";
        }

        // Implementering af interfacet
        // Interfacets metoder skal bare kalde de eksisterende metoder...
        public string SoundTheHorn()
        {
            // Vi antager at hornet er knyttet til knap nr. 0
            return PressButton(0);
        }

        public string TurnLeft(int degrees)
        {
            return MoveLeft(degrees);
        }

        public string TurnRight(int degrees)
        {
            return MoveRight(degrees);
        }
    }
}
