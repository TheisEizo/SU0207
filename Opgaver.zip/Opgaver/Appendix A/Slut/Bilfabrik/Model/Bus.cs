﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bilfabrik.Model.Steering;

namespace Bilfabrik.Model
{
    class Bus : Car
    {
        public Bus(string brand, int numberOfSeats, int numberOfWheels, ColorType color,  ISteering steering)
            : base(brand, numberOfSeats, numberOfWheels, color, CarType.Bus, steering)
        {
        }

        public override string TextAboutSeats
        {
            get
            {
                return "Skal have 9-30 sæder";
            }
        }

        public override string TextAboutWheels
        {
            get
            {
                return "Skal have 4 eller 6 hjul";
            }
        }

        public override bool SeatsIsAllowed()
        {
            return NumberOfSeats >= 9 && NumberOfSeats <= 30;
        }

        public override bool WheelsIsAllowed()
        {
            return NumberOfWheels == 4 || NumberOfWheels == 6;
        }
    }
}
