﻿namespace Bilfabrik
{
    enum CarType
    {
        Personal,
        SUV,
        Van,
        Truck,
    }
}
