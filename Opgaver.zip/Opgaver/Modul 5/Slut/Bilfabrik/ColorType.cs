﻿namespace Bilfabrik
{
    enum ColorType
    {
        Red, Green, Black, Yellow
    }
}
