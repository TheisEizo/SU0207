﻿using Bilfabrik.Model.Steering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bilfabrik.Model
{
    class Car
    {
        public static Car CreateCar(CarType type, string brand, int numberOfSeats, int numberOfWheels, ColorType color, SteeringType steeringType)
        {
            Car carToReturn = null;

            SteeringWheel steering = null;
            // Hvilken styring skal bruges 
            // - fra start er der kun rattet!
            switch (steeringType)
            {
                case SteeringType.SteeringWheel:
                    steering = new SteeringWheel();
                    break;
                default:
                    steering = new SteeringWheel();
                    break;
            }

            // Hvilken biltype
            // - Fra start har vi kun Car
            carToReturn = new Car(brand, numberOfSeats, numberOfWheels, color, type, steering);

            return carToReturn;
        }

        public Car(string brand, int numberOfSeats, int numberOfWheels, ColorType color, CarType type, SteeringWheel steering)
        {
            Brand = brand;
            NumberOfSeats = numberOfSeats;
            NumberOfWheels = numberOfWheels;
            Color = color;
            Type = type;

            Steering = steering;
        }

        public string Brand { get; set; }
        public int NumberOfSeats { get; set; }
        public int NumberOfWheels { get; set; }
        public ColorType Color { get; set; }
        public CarType Type { get; set; }

        public SteeringWheel Steering { get; set; }

        public override string ToString()
        {
            var text = string.Format("{0} {1} {2}, styret af {3}, med {4} sæder og {5} hjul.", Color, Brand, Type, Steering, NumberOfSeats, NumberOfWheels);
            return text;
        }
    }
}
