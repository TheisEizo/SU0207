﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bilfabrik.Model.Steering;

namespace Bilfabrik.Model
{
    class Truck : Car
    {
        public Truck(string brand, int numberOfSeats, int numberOfWheels, ColorType color, ISteering steering) 
            : base(brand, numberOfSeats, numberOfWheels, color,  CarType.Truck, steering)
        {
        }

        public override string TextAboutSeats
        {
            get
            {
                return "Skal have 2-3 sæder";
            }
        }

        public override string TextAboutWheels
        {
            get
            {
                return "Skal have et lige antal hjul, mellem 4 og 10;";
            }
        }

        public override bool SeatsIsAllowed(int numberOfSeats)
        {
            return numberOfSeats >= 2 && numberOfSeats <= 3;
        }

        public override bool WheelsIsAllowed(int numberOfWheels)
        {
            return numberOfWheels >= 4 && numberOfWheels <= 10 && numberOfWheels % 2 == 0;
        }
    }
}
