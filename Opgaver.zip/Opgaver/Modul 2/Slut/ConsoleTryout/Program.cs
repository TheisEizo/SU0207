﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTryout
{
    class Program
    {
        static void Main(string[] args)
        {
            // Indlæs 2 tal fra konsollen
            Console.Write("Indtast et heltal: ");
            string heltalStr = Console.ReadLine();

            Console.Write("Indtast et kommatal: ");
            string kommatalStr = Console.ReadLine();

            // Forkerte tal giver en fejl - fang dem, så programmet ikke går ned
            try
            {
                // Konvertér de indlæste tal
                var heltal = int.Parse(heltalStr);
                var kommatal = float.Parse(kommatalStr);

                // Beregn summen
                var resultat = heltal + kommatal;

                // Udskriv resultatet
                Console.WriteLine();
                Console.Write(heltal);
                Console.Write(" + ");
                Console.Write(kommatal);
                Console.Write(" = ");
                Console.Write(resultat);
                Console.WriteLine();
            }
            catch (Exception ex) // Fang exception og udskriv passende fejl
            {
                Console.Write("Fejl ved konverteringen: ");
                Console.Write(ex.Message);
                Console.WriteLine();
            }

            // Vent på at bruger trykker Enter, før konsollen lukker!
            Console.ReadLine(); // Vi BEHØVER ikke at bruge resultatet!
        }
    }
}
