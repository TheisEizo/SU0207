﻿using Bilfabrik.Model.Steering;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bilfabrik.Model
{
    abstract class Car : IComparable
    {

        #region static handling of SerialNumbers

        private static string serialNumberPersistPath = $"{Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)}\\serialNumber.txt";

        private static int _lastUsedSerialNumber;

        /// <summary>
        /// Metode, der gemmer det sidst brugte (aktuelle) løbenummer
        /// </summary>
        private static void saveLastUsedSerialNumber()
        {
            File.WriteAllText(serialNumberPersistPath, _lastUsedSerialNumber.ToString());
        }
        /// <summary>
        /// Static constructor, der initialiserer løbenummeret til den værdi, der er gemt i filen.
        /// </summary>
        static Car()
        {
            // Sæt startværdi til 0 - denne vil blive brugt hvis filen er tom, eller indeholder en ugyldig værdi
            _lastUsedSerialNumber = 0;
            if (File.Exists(serialNumberPersistPath))
            {
                var stringValue = File.ReadAllText(serialNumberPersistPath);
                // Benyt TryParse - denne bevarer den originale værdi, hvis Parse fejler
                int.TryParse(stringValue, out _lastUsedSerialNumber);
            }
        }
        /// <summary>
        /// metode, der udleverer et nyt løbenummernummer. Det brugte nummer gemmes samtidig i en fil
        /// </summary>
        /// <returns></returns>
        private static int getNewSerialNumber()
        {
            _lastUsedSerialNumber++;
            saveLastUsedSerialNumber();
            return _lastUsedSerialNumber;
        }

        #endregion


        /// <summary>
        /// Override of the Method, to allow creation based on the Car-viewmodel
        /// </summary>
        /// <param name="car"></param>
        /// <returns></returns>
        public static Car CreateCar(ViewModel.Car car)
        {
            return CreateCar(car.Type, getNewSerialNumber(), car.Brand, car.NumberOfSeats, car.NumberOfWheels, car.Color, car.Steering);
        }
        public static Car CreateCar(CarType type, int serialNumber, string brand, int numberOfSeats, int numberOfWheels, ColorType color, SteeringType steeringType)
        {
            Car carToReturn = null;

            ISteering steering = null;
            // Hvilken styring skal bruges 
            // - fra start er der kun rattet!
            switch (steeringType)
            {
                case SteeringType.SteeringWheel:
                    steering = new SteeringWheel();
                    break;
                case SteeringType.Joystick:
                    steering = new Joystick();
                    break;
                case SteeringType.Brain:
                    steering = new Brain();
                    break;
                default:
                    steering = new SteeringWheel();
                    break;
            }

            // Hvilken biltype - opret klasse, svarende til brugerens valg
            switch (type)
            {
                case CarType.Personal:
                    carToReturn = new Personal(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.SUV:
                    carToReturn = new SUV(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.Van:
                    carToReturn = new Van(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.Truck:
                    carToReturn = new Truck(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                case CarType.Bus:
                    carToReturn = new Bus(brand, numberOfSeats, numberOfWheels, color, steering);
                    break;
                default:
                    throw new NotImplementedException(string.Format("Enum: {0} not implemented", type));
            }

            // Sæt løbenummeret, hvis det ikke allerede er tildelt 
            if (serialNumber == 0)
                serialNumber = getNewSerialNumber();
            carToReturn.SerialNumber = serialNumber;

            return carToReturn;
        }
        public static Car CreateCar(string persistedCar)
        {
            Car result = null;

            var parts = persistedCar.Split(';');
            try
            {
                var serialNumber = int.Parse(parts[0]);
                var type = (CarType)Enum.Parse(typeof(CarType), parts[1]);
                var brand = parts[2];
                var color = (ColorType)Enum.Parse(typeof(ColorType), parts[3]);
                var numberOfWheels = int.Parse(parts[4]);
                var numberOfSeats = int.Parse(parts[5]);
                var steering = (SteeringType)Enum.Parse(typeof(SteeringType), parts[6]);


                result = CreateCar(type, serialNumber, brand, numberOfSeats, numberOfWheels, color, steering);
            }
            catch
            {
                // Ingen kode - vil bare returnere en null-værdi
            }
            return result;
        }

        public Car(string brand, int numberOfSeats, int numberOfWheels, ColorType color, CarType type, ISteering steering)
        {
            Brand = brand;
            NumberOfSeats = numberOfSeats;
            NumberOfWheels = numberOfWheels;
            Color = color;
            Type = type;

            Steering = steering;
        }

        public string GetPersistingString()
        {
            // Alternativ placering for løbenummerkode:
            // Tildel et nyt løbenummer hér, hvis den aktuelle værdi er 0 (dvs. ikke sat)
            var result = $"{SerialNumber};{Type};{Brand};{Color};{NumberOfWheels};{NumberOfSeats};{Steering.GetType().Name}";
            return result;
        }


        public int SerialNumber { get; private set; }
        public string Brand { get; set; }
        public int NumberOfSeats { get; set; }
        public int NumberOfWheels { get; set; }
        public ColorType Color { get; set; }
        public CarType Type { get; set; }

        public ISteering Steering { get; set; }

        // Metoder til at håndtere antal sæder og hjul
        // - skal implementeres i de nedarvende klasser!
        public abstract bool WheelsIsAllowed();
        public abstract string TextAboutWheels { get; }
        public abstract bool SeatsIsAllowed();
        public abstract string TextAboutSeats { get; }


        public override string ToString()
        {
            // Note: Løbenummeret er sat som SIDSTE parameter og får dermed index 6
            var text = string.Format("{6}: {0} {1} {2}, styret af {3}, med {4} sæder og {5} hjul.", Color, Brand, Type, Steering, NumberOfSeats, NumberOfWheels, SerialNumber);
            return text;
        }

        public int CompareTo(object obj)
        {
            // obj er en anden instans af Car, så vi kan Cast'e.
            // Vi sammenligner på Brand - så kan vi bruge CompareTo-metoden direkte på variablen
            return Brand.CompareTo(((Car)obj).Brand);

        }
    }
}
