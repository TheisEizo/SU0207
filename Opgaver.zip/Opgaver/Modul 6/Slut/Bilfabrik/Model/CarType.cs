﻿namespace Bilfabrik.Model
{
    enum CarType
    {
        Personal,
        SUV,
        Van,
        Truck,
    }
}
