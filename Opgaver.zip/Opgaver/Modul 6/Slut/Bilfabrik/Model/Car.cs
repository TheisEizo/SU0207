﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bilfabrik.Model
{
    class Car
    {
        public Car(string brand, int numberOfSeats, int numberOfWheels, ColorType color, CarType type)
        {
            Brand = brand;
            NumberOfSeats = numberOfSeats;
            NumberOfWheels = numberOfWheels;
            Color = color;
            Type = type;
        }

        public string Brand { get; set; }
        public int NumberOfSeats { get; set; }
        public int NumberOfWheels { get; set; }
        public ColorType Color { get; set; }
        public CarType Type { get; set; }

        public override string ToString()
        {
            var text = string.Format("{0} {1} {2}, med {3} sæder og {4} hjul.", Color, Brand, Type, NumberOfSeats, NumberOfWheels);
            return text;
        }
    }
}
