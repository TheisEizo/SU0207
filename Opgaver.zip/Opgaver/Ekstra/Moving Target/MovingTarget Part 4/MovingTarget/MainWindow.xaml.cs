﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MovingTarget
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer _timer;

        public MainWindow()
        {
            InitializeComponent();
            _timer = new DispatcherTimer();
            _timer.Interval = new TimeSpan(0, 0, 2); // Every 2 seconds
            _timer.Tick += moveToRandomPos;
            _timer.Start();
        }

        private void moveToRandomPos(object sender, EventArgs e)
        {
            var rand = new Random();

            this.Left = rand.Next(0, (int)System.Windows.SystemParameters.PrimaryScreenWidth);
            this.Top = rand.Next(0, (int)System.Windows.SystemParameters.PrimaryScreenHeight);
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var window = (Window)sender;
            var oldBackgroundColor = window.Background;
            window.Background = Brushes.Red;
            MessageBox.Show("HIT!");

            window.Background = oldBackgroundColor;
        }

    }
}
