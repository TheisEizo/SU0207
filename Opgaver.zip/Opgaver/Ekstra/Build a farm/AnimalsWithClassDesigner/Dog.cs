﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimalsWithClassDesigner
{
    public class Dog : Animal
    {
        public Dog(string name)
        {
            Name = name;
        }
    }
}