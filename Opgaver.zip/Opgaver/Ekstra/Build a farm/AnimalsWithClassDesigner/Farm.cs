﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnimalsWithClassDesigner
{
    public class Farm
    {
        private List<Animal> _Animals = new List<Animal>();

        public List<Animal> Animals
        {
            get { return _Animals; }
            set { _Animals = value; }
        }

        public void HearAllTheAnimalsSound()
        {
            foreach (var animal in Animals)
            {
                animal.MakeSound();
            }
        }
    }
}