﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsWithClassDesigner
{
    public abstract class Animal
    {
        public void MakeSound()
        {
            Console.WriteLine("I am a {0} named {1} and i say \"{2}\"", this.GetType().Name, _Name, _Sound);
        }

        private string _Sound;

        public string Sound
        {
            get { return _Sound; }
            set { _Sound = value; }
        }
        private string _Name;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

    }
}
